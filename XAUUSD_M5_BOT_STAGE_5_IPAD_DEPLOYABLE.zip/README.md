# XAUUSD M5 Bot — Stage 2 Prototype

Cross-platform mobile prototype (Expo/React Native) plus Node/Express paper-trading engine.

## Included
- XAUUSD M5 candle simulation and live-style 1-second updates
- EMA 9 / EMA 21, RSI 14 and ATR 14 calculations
- EMA/RSI signal engine
- ATR-based stop loss and take profit
- Risk-based paper position sizing
- Daily loss and max-trades protections
- Paper broker adapter
- Start/stop controls and trade history API
- Mobile dashboard for iPhone/iPad/Android
- Broker adapter boundary for a future MT5/live integration

## Run server
```bash
cd server
npm install
npm start
```
Default API: http://localhost:3000

## Run mobile app
```bash
cd mobile
npm install
npx expo start
```
Set `EXPO_PUBLIC_API_URL` to a reachable server address when testing on a physical device, e.g. `http://192.168.1.20:3000`.

## API
- GET `/api/health`
- GET `/api/status`
- GET `/api/trades`
- POST `/api/bot/start`
- POST `/api/bot/stop`
- POST `/api/paper/simulate`
- POST `/api/settings`

## Safety
This Stage 2 build is paper-only. It does not contain live broker credentials or live execution. Do not treat simulated performance as evidence of profitability. The next stage should use a real market-data feed and an MT5 demo account before any live execution.
