# Stage 5 cloud deployment (iPad-friendly)

Recommended host: Render Web Service. The app listens on 0.0.0.0 and uses PORT supplied by Render.

1. Put this folder in a GitHub repository.
2. On iPad, open Render Dashboard and choose New -> Web Service.
3. Connect the GitHub repository.
4. Render can use `render.yaml`, or enter:
   - Build command: `npm install`
   - Start command: `npm start`
5. Add secrets in Render Environment:
   - APP_PASSWORD = a long unique password
   - MARKET_DATA_API_KEY = your Twelve Data API key
6. Confirm:
   - MARKET_DATA_PROVIDER=twelvedata
   - MARKET_DATA_SYMBOL=XAU/USD
   - MARKET_DATA_INTERVAL=5min
7. Deploy and open the generated https://*.onrender.com URL in Safari.
8. Verify `/api/health` reports mode `paper` and `liveTrading:false`.

Never commit `.env` or API keys to GitHub. Live order execution is intentionally not included in Stage 5.
