# XAUUSD M5 Bot — Stage 3 iPad Edition

A browser-based iPad dashboard served by the Stage 2 Node/Express API. It can be installed to the iPad Home Screen as a web app (PWA) when hosted over HTTPS.

## What is included
- iPad-first responsive browser dashboard
- XAUUSD M5 paper market simulation
- EMA 9 / EMA 21, RSI 14, ATR 14
- Paper BUY/SELL signal and order simulation
- ATR stop-loss/take-profit
- Risk %, daily-loss %, max-trades, spread settings
- Start/stop controls
- Open position and trade history
- PWA manifest and service worker
- Existing API/strategy retained
- Live broker execution is NOT included

## Run locally (development)
On a computer with Node.js:
```bash
cd xauusd_m5_bot/server
npm install
npm start
```
Open `http://localhost:3000` in a browser.

## Use from an iPad
For iPad-only access, host this app on an HTTPS Node service (or a static frontend plus a separately hosted API). Open the HTTPS URL in Safari and choose **Share → Add to Home Screen**.

The iPad browser must be able to reach the API. The included server serves both the web app and API from the same origin.

## Production next step
Deploy the Node service to a cloud host, add authentication, persistent database storage, real market-data feed, monitoring, and a broker/MT5 demo adapter. Keep live order routing disabled until the complete system is tested.

## Safety
This is a paper-trading prototype. Simulated results are not evidence of profitability. XAUUSD can move rapidly and real execution involves spread, slippage, latency and broker-specific contract specifications.
