class BrokerAdapter {
  constructor(){ this.mode = 'paper'; }
  async connect(){ return {connected:false, mode:this.mode, message:'Live broker adapter is intentionally disabled.'}; }
  async placeOrder(){ throw new Error('Live execution is disabled. Use paper mode until a broker adapter is configured.'); }
  async closePosition(){ throw new Error('Live execution is disabled.'); }
}
class PaperBroker extends BrokerAdapter {
  constructor(){ super(); this.mode='paper'; this.orders=[]; }
  async placeOrder(order){
    const id = `P-${Date.now()}`;
    const filled = {...order,id,status:'FILLED',filledAt:new Date().toISOString()};
    this.orders.push(filled); return filled;
  }
}
module.exports = { BrokerAdapter, PaperBroker };
