const { ema, rsi, atr } = require('./indicators');
const { PaperBroker } = require('./broker');

class Strategy {
  constructor(){
    this.running=false; this.mode='paper'; this.price=4325.20; this.pnl=0; this.balance=10000;
    this.position=null; this.trades=[]; this.candles=this.seedCandles(); this.broker=new PaperBroker();
    this.settings={riskPercent:1,dailyLossPercent:3,maxTradesPerDay:3,atrSL:1.5,atrTP:2,fastEMA:9,slowEMA:21,rsiPeriod:14,spreadMax:0.80};
    this.lastSignal='WAIT'; this.lastCandleTime=this.candles.at(-1).time; this.startedAt=null;
  }
  seedCandles(){let p=this.price||4325.2; const a=[]; const now=Date.now()-120*300000; for(let i=0;i<120;i++){const drift=Math.sin(i/9)*0.35+(Math.random()-0.5)*1.8; const open=p, close=p+drift, high=Math.max(open,close)+Math.random()*1.1, low=Math.min(open,close)-Math.random()*1.1; a.push({time:new Date(now+i*300000).toISOString(),open,high,low,close}); p=close;} this.price=p; return a;}
  indicators(){const closes=this.candles.map(c=>c.close); return {ema9:ema(closes,this.settings.fastEMA),ema21:ema(closes,this.settings.slowEMA),rsi:rsi(closes,this.settings.rsiPeriod),atr:atr(this.candles,14)};}
  signal(){const x=this.indicators(); if(x.ema9>x.ema21&&x.rsi>50)return 'BUY'; if(x.ema9<x.ema21&&x.rsi<50)return 'SELL'; return 'WAIT';}
  status(){const x=this.indicators(); return {running:this.running,mode:this.mode,symbol:'XAUUSD',timeframe:'M5',price:this.price,ema9:x.ema9,ema21:x.ema21,rsi:x.rsi,atr:x.atr,signal:this.lastSignal||this.signal(),pnl:this.pnl,balance:this.balance,position:this.position,tradesToday:this.tradesToday(),settings:this.settings,broker:'PAPER',lastUpdate:new Date().toISOString()};}
  updateSettings(x){for(const k of Object.keys(this.settings)){if(x[k]!==undefined){const n=Number(x[k]); if(Number.isFinite(n)&&n>0)this.settings[k]=n;}} return this.status();}
  tradesToday(){const d=new Date().toISOString().slice(0,10); return this.trades.filter(t=>t.openedAt.slice(0,10)===d).length;}
  dailyLossExceeded(){return this.pnl <= -(this.balance*this.settings.dailyLossPercent/100);}
  riskLots(slDistance){const risk=this.balance*this.settings.riskPercent/100; const valuePerUnit=100; return Math.max(0.01, Number((risk/(slDistance*valuePerUnit)).toFixed(2)));}
  async simulatePaper(){
    const s=this.signal(); if(s==='WAIT') return {ok:false,message:'No valid EMA/RSI signal.'};
    if(this.position) return {ok:false,message:'Position already open.'};
    if(this.tradesToday()>=this.settings.maxTradesPerDay) return {ok:false,message:'Daily trade limit reached.'};
    if(this.dailyLossExceeded()) return {ok:false,message:'Daily loss limit reached.'};
    const x=this.indicators(), entry=this.price, slDist=Math.max(x.atr*this.settings.atrSL,0.5), tpDist=Math.max(x.atr*this.settings.atrTP,0.5);
    const side=s, sl=side==='BUY'?entry-slDist:entry+slDist, tp=side==='BUY'?entry+tpDist:entry-tpDist;
    const order=await this.broker.placeOrder({symbol:'XAUUSD',timeframe:'M5',side,entry,sl,tp,lots:this.riskLots(slDist)});
    this.position={...order,openedAt:order.filledAt}; this.trades.push({...order,openedAt:order.filledAt}); this.lastSignal=s;
    return {ok:true,trade:this.position};
  }
  tick(){
    const prev=this.price; const shock=(Math.random()-0.5)*3.2 + Math.sin(Date.now()/90000)*0.35; this.price=Math.max(100,this.price+shock);
    const last=this.candles.at(-1); const candle={...last,close:this.price,high:Math.max(last.high,this.price),low:Math.min(last.low,this.price)}; this.candles[this.candles.length-1]=candle;
    if(Date.now()-new Date(last.time).getTime()>=300000){this.candles.push({time:new Date().toISOString(),open:this.price,high:this.price,low:this.price,close:this.price}); if(this.candles.length>250)this.candles.shift(); this.lastSignal=this.signal(); if(this.running&&this.lastSignal!=='WAIT') this.simulatePaper().catch(()=>{});}
    if(this.position){const p=this.position; const hit=p.side==='BUY'?(this.price<=p.sl||this.price>=p.tp):(this.price>=p.sl||this.price<=p.tp); if(hit){const delta=p.side==='BUY'?this.price-p.entry:p.entry-this.price; const profit=delta*p.lots*100; this.pnl+=profit; this.balance+=profit; this.position=null; this.trades.push({...p,closedAt:new Date().toISOString(),exit:this.price,profit});}}
    return this.status();
  }
}
module.exports={Strategy};
