# XAUUSD M5 Bot — Stage 5 iPad Edition

Stage 5 adds a cloud-ready real-market-data adapter while keeping **live order execution disabled**.

## What changed
- Server-side market-data adapter for Twelve Data.
- XAU/USD 5-minute OHLC ingestion; the API supports `5min` intervals and `XAU/USD` as the gold spot symbol. See the official docs: https://twelvedata.com/docs
- `/api/market/status`, `/api/market/candles`, and `/api/market/sync` endpoints.
- Strategy can ingest provider candles instead of the demo feed.
- Existing EMA 9/21 + RSI 14 + ATR 14 paper strategy remains in place.
- Live broker/order routing remains disabled.

## Run locally
1. Copy `server/.env.example` to `server/.env`.
2. Leave `MARKET_DATA_PROVIDER=demo` for simulation, or set `MARKET_DATA_PROVIDER=twelvedata` and add your own API key.
3. From `server/`, run `npm install` then `npm start`.
4. Open the server URL in Safari on the iPad.

## Cloud deployment
Deploy the `server/` service with Node 18+ (or a current Node runtime) and persistent storage for `DATA_FILE`. Set environment variables in the host dashboard; do not put the API key into browser JavaScript.

For an internet-facing deployment, also put the app behind HTTPS and use a strong password. This prototype uses in-memory sessions, so a multi-instance deployment needs a shared session store before production use.

## Market-data notes
The provider adapter fetches server-side so the API key is not exposed to the iPad. The Twelve Data documentation states `/time_series` supports `5min` intervals and the commodities docs identify `XAU/USD` as Gold Spot. Provider limits/entitlements vary by account, so verify the plan and data rights before deployment.

## Safety
This stage is paper trading only. It does not contain live order placement, broker credentials, or a live execution endpoint.
