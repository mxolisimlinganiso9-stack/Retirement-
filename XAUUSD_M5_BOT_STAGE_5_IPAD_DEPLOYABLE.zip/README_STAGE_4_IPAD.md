# XAUUSD M5 Bot — Stage 4 iPad Edition

Stage 4 adds a deployable cloud-ready web app layer on top of Stage 3.

## New
- Password-protected API/session token
- Persistent JSON state for settings and paper trade history
- Production-oriented environment variables
- Docker deployment recipe
- iPad Safari / Add to Home Screen workflow
- Same-origin web + API to simplify hosting
- Live broker execution remains disabled

## Local test
```bash
cd server
npm install
APP_PASSWORD='test-password' npm start
```
Open `http://localhost:3000` and sign in with the configured password.

## iPad
Deploy the service behind HTTPS, open the URL in Safari, sign in, then Share -> Add to Home Screen.

## Safety
This build is paper trading only. It does not connect to a live broker or place real orders.
