# API sketch

GET /api/status
POST /api/bot/start
POST /api/bot/stop
POST /api/settings
POST /api/paper/simulate

Production additions:
POST /api/auth/login
GET /api/account
GET /api/positions
GET /api/orders
POST /api/positions/:id/close
GET /api/events
POST /api/broker/connect
POST /api/broker/disconnect
