# Stage 2 Architecture

```text
iOS / iPadOS / Android (Expo React Native)
                 |
                 v
          Node/Express API
                 |
       +---------+----------+
       |                    |
 Strategy Engine       Trade History
       |                    |
 Indicators            Risk Controls
       |                    |
       +---------> Paper Broker
                         |
                Future MT5 Adapter
```

## Components
- `mobile/App.tsx`: mobile dashboard and controls.
- `server/server.js`: HTTP API and update loop.
- `strategy/strategy.js`: M5 signal, risk, position and paper execution logic.
- `strategy/indicators.js`: EMA, RSI and ATR calculations.
- `strategy/broker.js`: broker abstraction and paper adapter.

## Production path
1. Replace simulated candles with a licensed/authorized XAUUSD M5 feed.
2. Add authenticated users and encrypted secrets.
3. Persist state/trades in PostgreSQL or another durable database.
4. Add WebSocket updates and push notifications.
5. Implement an MT5 execution adapter with demo-account support.
6. Add reconciliation, idempotency, slippage checks, kill switch and audit logs.
7. Run historical and forward testing before enabling live execution.
