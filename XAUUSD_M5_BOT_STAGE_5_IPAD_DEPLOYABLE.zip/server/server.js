const express=require('express');
const path=require('path');
const crypto=require('crypto');
const fs=require('fs');
const cors=require('cors');
const {Strategy}=require('../strategy/strategy');
const {MarketDataProvider}=require('./marketData');

const app=express();
const PORT=Number(process.env.PORT||3000);
const HOST=process.env.HOST||'0.0.0.0';
const APP_PASSWORD=process.env.APP_PASSWORD||'change-me-before-deploying';
const DATA_FILE=process.env.DATA_FILE||path.join(__dirname,'data','state.json');
const sessions=new Map();
const strategy=new Strategy();
const marketData=new MarketDataProvider();
let marketState={provider:marketData.provider,symbol:marketData.symbol,interval:marketData.interval,connected:false,lastSync:null,error:null};

app.disable('x-powered-by');
app.use(cors());
app.use(express.json({limit:'32kb'}));
app.use(express.static(path.join(__dirname,'../web')));

function loadState(){
  try{ if(fs.existsSync(DATA_FILE)){ const s=JSON.parse(fs.readFileSync(DATA_FILE,'utf8')); if(s.settings) strategy.updateSettings(s.settings); if(Array.isArray(s.trades)) strategy.trades=s.trades; } }
  catch(e){ console.error('State load failed:',e.message); }
}
function saveState(){
  try{ fs.mkdirSync(path.dirname(DATA_FILE),{recursive:true}); fs.writeFileSync(DATA_FILE,JSON.stringify({settings:strategy.settings,trades:strategy.trades},null,2)); }
  catch(e){ console.error('State save failed:',e.message); }
}
function auth(req,res,next){
  const token=req.headers.authorization?.replace(/^Bearer\s+/i,'');
  if(!token || !sessions.has(token)) return res.status(401).json({ok:false,message:'Authentication required'});
  next();
}

app.get('/api/health',(req,res)=>res.json({ok:true,service:'xauusd-m5-bot',mode:'paper',liveTrading:false,market:marketState}));
app.get('/api/market/status',auth,(req,res)=>res.json(marketState));
app.get('/api/market/candles',auth,(req,res)=>res.json({candles:strategy.candles,market:marketState}));
app.post('/api/market/sync',auth,async(req,res)=>{try{const candles=await marketData.getCandles(); strategy.setCandles(candles); marketState={...marketState,connected:true,lastSync:new Date().toISOString(),error:null}; saveState(); res.json({ok:true,count:candles.length,market:marketState,status:strategy.status()});}catch(e){marketState={...marketState,connected:false,error:e.message}; res.status(503).json({ok:false,message:e.message,market:marketState});}});
app.post('/api/auth/login',(req,res)=>{
  if(req.body?.password!==APP_PASSWORD) return res.status(401).json({ok:false,message:'Invalid password'});
  const token=crypto.randomBytes(32).toString('hex'); sessions.set(token,Date.now());
  res.json({ok:true,token});
});
app.post('/api/auth/logout',auth,(req,res)=>{ const token=req.headers.authorization.replace(/^Bearer\s+/i,''); sessions.delete(token); res.json({ok:true}); });
app.get('/api/status',auth,(req,res)=>res.json(strategy.status()));
app.get('/api/trades',auth,(req,res)=>res.json({trades:strategy.trades}));
app.post('/api/bot/start',auth,(req,res)=>{strategy.running=true;strategy.startedAt=new Date().toISOString();saveState();res.json(strategy.status())});
app.post('/api/bot/stop',auth,(req,res)=>{strategy.running=false;saveState();res.json(strategy.status())});
app.post('/api/paper/simulate',auth,async(req,res)=>{try{const out=await strategy.simulatePaper();saveState();res.json(out)}catch(e){res.status(400).json({ok:false,message:e.message})}});
app.post('/api/settings',auth,(req,res)=>{const out=strategy.updateSettings(req.body||{});saveState();res.json(out)});

app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'../web/index.html')));

loadState();
app.listen(PORT,HOST,()=>console.log(`XAUUSD M5 Stage 4 running at http://${HOST}:${PORT}`));
const tickTimer=setInterval(()=>{strategy.tick(); if(strategy.trades.length%5===0) saveState();},1000);
const syncMinutes=Number(process.env.MARKET_SYNC_MINUTES||5);
if(marketData.provider!=='demo'){
  const sync=async()=>{try{const candles=await marketData.getCandles(); strategy.setCandles(candles); marketState={...marketState,connected:true,lastSync:new Date().toISOString(),error:null}; saveState(); console.log('Market data synced:',candles.length);}catch(e){marketState={...marketState,connected:false,error:e.message}; console.error('Market sync failed:',e.message);}};
  sync(); setInterval(sync,Math.max(1,syncMinutes)*60000);
}
