class MarketDataProvider {
  constructor(){
    this.provider=process.env.MARKET_DATA_PROVIDER||'demo';
    this.apiKey=process.env.MARKET_DATA_API_KEY||'';
    this.symbol=process.env.MARKET_DATA_SYMBOL||'XAU/USD';
    this.interval=process.env.MARKET_DATA_INTERVAL||'5min';
    this.baseUrl=process.env.MARKET_DATA_BASE_URL||'https://api.twelvedata.com/time_series';
  }
  async getCandles(outputsize=250){
    if(this.provider!=='twelvedata') throw new Error('Market-data provider is demo. Set MARKET_DATA_PROVIDER=twelvedata.');
    if(!this.apiKey) throw new Error('MARKET_DATA_API_KEY is not configured.');
    const url=new URL(this.baseUrl);
    url.searchParams.set('symbol',this.symbol);
    url.searchParams.set('interval',this.interval);
    url.searchParams.set('outputsize',String(Math.min(outputsize,5000)));
    url.searchParams.set('timezone','UTC');
    url.searchParams.set('apikey',this.apiKey);
    const r=await fetch(url);
    const data=await r.json();
    if(!r.ok || data.status==='error') throw new Error(data.message||`Market data HTTP ${r.status}`);
    const values=(data.values||[]).slice().reverse().map(v=>({
      time:new Date(v.datetime+'Z').toISOString(),open:Number(v.open),high:Number(v.high),low:Number(v.low),close:Number(v.close)
    })).filter(c=>Object.values(c).every(Number.isFinite));
    if(values.length<30) throw new Error('Market-data provider returned too few candles.');
    return values;
  }
}
module.exports={MarketDataProvider};
