# Stage 4 deployment

The Stage 4 server is cloud-ready and serves the iPad web app and API from one origin.

## Docker
From the project root:

```bash
docker build -f deploy/Dockerfile -t xauusd-m5-bot .
docker run --rm -p 3000:3000 -e APP_PASSWORD='use-a-long-random-password' xauusd-m5-bot
```

Open the resulting HTTPS deployment URL in Safari. Use Share -> Add to Home Screen.

## Required production settings
- Set a strong `APP_PASSWORD` as a secret.
- Put the service behind HTTPS.
- Persist `/app/data` so settings/trade history survive restarts.
- Keep live broker routing disabled until demo testing is complete.
